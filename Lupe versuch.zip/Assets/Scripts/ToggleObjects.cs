using UnityEngine;

public class ToggleObjects : MonoBehaviour
{
    public GameObject[] objectsToToggle;

    private void Start()
    {
        foreach (GameObject obj in objectsToToggle)
        {
            if (obj != null)
            {
                obj.SetActive(false);
            }
        }
    }

    public void ToggleVisibility()
    {
        foreach (GameObject obj in objectsToToggle)
        {
            if (obj != null)
            {
                bool isActive = obj.activeSelf;
                obj.SetActive(!isActive);
            }
        }
    }
}
