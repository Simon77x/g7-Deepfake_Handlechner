using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lens : MonoBehaviour 
{
    public Transform smaallSheet, bigSheet;

    private void Update()
    {
        bigSheet.position = smaallSheet.position * 2 - transform.position;
    }
}
