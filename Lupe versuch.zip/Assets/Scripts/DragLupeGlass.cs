using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DragLupeGlass : MonoBehaviour
{
    Vector2 mousePosition;
    Vector2 dragOffset;

    void OnMouseDown()
    {
        dragOffset = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
    }

    void OnMouseDrag()
    {
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        transform.position = mousePosition - dragOffset;
    }
}
